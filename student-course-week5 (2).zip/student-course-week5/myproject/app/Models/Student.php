<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Student extends Model
{
    use HasFactory;

    /**
     * Columns that may be filled with Student::create([...]).
     */
    protected $fillable = [
        'name',
        'email',
        'phone',
        'date_of_birth',
    ];

    /**
     * Turn date_of_birth into a Carbon date object automatically.
     */
    protected function casts(): array
    {
        return [
            'date_of_birth' => 'date',
        ];
    }

    /**
     * A student can be enrolled on many courses.
     */
    public function courses(): BelongsToMany
    {
        return $this->belongsToMany(Course::class)
            ->withPivot('enrolled_on', 'grade')
            ->withTimestamps();
    }
}
