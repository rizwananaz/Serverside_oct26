<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Course extends Model
{
    use HasFactory;

    /**
     * Columns that may be filled with Course::create([...]).
     */
    protected $fillable = [
        'code',
        'title',
        'description',
        'credits',
    ];

    /**
     * A course can have many students.
     */
    public function students(): BelongsToMany
    {
        return $this->belongsToMany(Student::class)
            ->withPivot('enrolled_on', 'grade')
            ->withTimestamps();
    }
}
