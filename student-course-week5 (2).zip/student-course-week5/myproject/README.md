# Student & Course – Laravel (migrations and seeders)

These are the files you add to a fresh Laravel project.

1. `composer create-project laravel/laravel student-course`
2. Copy the `app` and `database` folders from this zip into the new project (say yes to replace `DatabaseSeeder.php`).
3. Make sure `database/database.sqlite` exists (or set MySQL in `.env`).
4. `php artisan migrate:fresh --seed`
5. Check with `php artisan tinker` → `App\Models\Student::count();`

Contents:

- `app/Models/Student.php`, `app/Models/Course.php` – models with the many-to-many relationship
- `database/migrations/` – students, courses, course_student (pivot)
- `database/factories/` – StudentFactory, CourseFactory
- `database/seeders/` – CourseSeeder, StudentSeeder, EnrollmentSeeder, DatabaseSeeder

Result: 8 courses, 21 students, each student enrolled on 2–4 courses.

The full step-by-step guide is in Student_Course_Laravel_Guide.docx.
