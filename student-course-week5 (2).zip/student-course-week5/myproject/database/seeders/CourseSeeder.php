<?php

namespace Database\Seeders;

use App\Models\Course;
use Illuminate\Database\Seeder;

class CourseSeeder extends Seeder
{
    /**
     * Add a fixed list of real-looking courses.
     */
    public function run(): void
    {
        $courses = [
            ['code' => 'CS101', 'title' => 'Introduction to Programming', 'credits' => 4],
            ['code' => 'CS102', 'title' => 'Web Development with PHP',    'credits' => 4],
            ['code' => 'CS201', 'title' => 'Databases and SQL',           'credits' => 3],
            ['code' => 'CS202', 'title' => 'Laravel Framework',           'credits' => 4],
            ['code' => 'CS203', 'title' => 'Python and Flask',            'credits' => 3],
            ['code' => 'MA101', 'title' => 'Discrete Mathematics',        'credits' => 3],
            ['code' => 'NW101', 'title' => 'Computer Networks',           'credits' => 3],
            ['code' => 'SE301', 'title' => 'Software Engineering',        'credits' => 4],
        ];

        foreach ($courses as $course) {
            $course['description'] = $course['code'] . ': ' . $course['title'] . '.';

            // updateOrCreate: running the seeder twice won't make duplicates
            Course::updateOrCreate(['code' => $course['code']], $course);
        }
    }
}
