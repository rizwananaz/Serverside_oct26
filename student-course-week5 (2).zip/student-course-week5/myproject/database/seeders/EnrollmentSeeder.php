<?php

namespace Database\Seeders;

use App\Models\Course;
use App\Models\Student;
use Illuminate\Database\Seeder;

class EnrollmentSeeder extends Seeder
{
    /**
     * Enrol every student on 2 to 4 random courses
     * (this fills the course_student pivot table).
     */
    public function run(): void
    {
        $courseIds = Course::pluck('id');
        $grades = ['A', 'B', 'C', 'D', null];   // null = not graded yet

        Student::all()->each(function (Student $student) use ($courseIds, $grades) {
            $chosen = $courseIds->random(rand(2, 4));

            $rows = [];
            foreach ($chosen as $courseId) {
                $rows[$courseId] = [
                    'enrolled_on' => fake()->dateTimeBetween('-1 year', 'now')->format('Y-m-d'),
                    'grade'       => $grades[array_rand($grades)],
                ];
            }

            // sync() replaces the student's enrolments, so re-seeding never duplicates
            $student->courses()->sync($rows);
        });
    }
}
