<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Main seeder: `php artisan db:seed` runs this file.
     * Order matters - courses and students must exist before enrolments.
     */
    public function run(): void
    {
        $this->call([
            CourseSeeder::class,
            StudentSeeder::class,
            EnrollmentSeeder::class,
        ]);
    }
}
