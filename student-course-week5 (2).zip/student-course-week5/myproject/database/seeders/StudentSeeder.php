<?php

namespace Database\Seeders;

use App\Models\Student;
use Illuminate\Database\Seeder;

class StudentSeeder extends Seeder
{
    /**
     * Add one known student plus 20 fake students.
     */
    public function run(): void
    {
        // A fixed student that is easy to find when testing
        Student::updateOrCreate(
            ['email' => 'ali.khan@example.com'],
            ['name' => 'Ali Khan', 'phone' => '07123456789', 'date_of_birth' => '2005-04-12']
        );

        // 20 random students from StudentFactory
        Student::factory()->count(20)->create();
    }
}
