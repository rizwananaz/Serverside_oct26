<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migration: create the courses table.
     */
    public function up(): void
    {
        Schema::create('courses', function (Blueprint $table) {
            $table->id();                                   // id (primary key)
            $table->string('code', 10)->unique();           // e.g. CS101
            $table->string('title');                        // e.g. Introduction to Programming
            $table->text('description')->nullable();        // optional longer text
            $table->unsignedTinyInteger('credits')->default(3);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migration: drop the courses table.
     */
    public function down(): void
    {
        Schema::dropIfExists('courses');
    }
};
