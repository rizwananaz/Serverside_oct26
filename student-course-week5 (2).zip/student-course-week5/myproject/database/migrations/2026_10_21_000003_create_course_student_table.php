<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migration: create the pivot (enrolment) table.
     *
     * Laravel's naming rule for a many-to-many pivot table:
     * the two model names in singular, in alphabetical order,
     * joined by an underscore  ->  course_student
     */
    public function up(): void
    {
        Schema::create('course_student', function (Blueprint $table) {
            $table->id();

            // Foreign keys. If a student or course is deleted,
            // their enrolment rows are deleted too.
            $table->foreignId('student_id')->constrained()->cascadeOnDelete();
            $table->foreignId('course_id')->constrained()->cascadeOnDelete();

            // Extra data about the enrolment itself
            $table->date('enrolled_on');
            $table->string('grade', 2)->nullable();         // A, B, C ... (null = not graded yet)

            $table->timestamps();

            // A student can only enrol on the same course once
            $table->unique(['student_id', 'course_id']);
        });
    }

    /**
     * Reverse the migration: drop the pivot table.
     */
    public function down(): void
    {
        Schema::dropIfExists('course_student');
    }
};
