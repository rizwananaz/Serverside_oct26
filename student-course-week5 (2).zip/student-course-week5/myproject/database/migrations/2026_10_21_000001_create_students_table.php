<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migration: create the students table.
     */
    public function up(): void
    {
        Schema::create('students', function (Blueprint $table) {
            $table->id();                                   // id (primary key)
            $table->string('name');                         // full name
            $table->string('email')->unique();              // no two students share an email
            $table->string('phone', 20)->nullable();        // optional
            $table->date('date_of_birth')->nullable();      // optional
            $table->timestamps();                           // created_at, updated_at
        });
    }

    /**
     * Reverse the migration: drop the students table.
     */
    public function down(): void
    {
        Schema::dropIfExists('students');
    }
};
