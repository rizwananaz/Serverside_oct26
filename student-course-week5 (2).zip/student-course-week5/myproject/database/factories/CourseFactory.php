<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Course>
 */
class CourseFactory extends Factory
{
    /**
     * Fake data for one course.
     */
    public function definition(): array
    {
        return [
            'code'        => strtoupper(fake()->unique()->bothify('??###')),   // e.g. KX402
            'title'       => ucwords(fake()->words(3, true)),
            'description' => fake()->sentence(12),
            'credits'     => fake()->numberBetween(1, 6),
        ];
    }
}
